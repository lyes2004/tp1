<?php
require_once "Animal.php";
class Chien extends Animal{
    public $race;


    public function getChien($id){
        global $oPDO;
        //prepation de la requete sql 

        $oPDOStmt = $oPDO->prepare('SELECT id,sexe,nom,anneeDeNaissance FROM chien WHERE id = :id');
        $oPDOStmt->bindParam(':id',$id, PDO::PARAM_INT);

        //execution de la requette sql 
        $oPDOStmt->execute();

        $chien = $oPDOStmt->fetch(PDO::FETCH_ASSOC);
        return $chien;
    }

    public function getAllChiens(){
        global $oPDO;
        //prepation de la requete sql 

        $oPDOStmt = $oPDO->prepare('SELECT id,sexe,nom,anneeDeNaissance FROM chien ');

        //execution de la requette sql 
        $oPDOStmt->execute();

        $chiens = $oPDOStmt->fetchAll(PDO::FETCH_ASSOC);
        return $chiens;
    }

    public function createChien($id,$nom,$race,$anneeNaiss,$sexe){
        global $oPDO;
        //prepation de la requete sql 

        $oPDOStmt = $oPDO->prepare('INSERT INTO chien (id,sexe,nom,anneeDeNaissance,race) VALUES (:id,:sexe,:nom,:anneeDeNaissance,:race)');
        $oPDOStmt->bindParam(':id',$id, PDO::PARAM_INT);
        $oPDOStmt->bindParam(':sexe',$sexe, PDO::PARAM_STR);
        $oPDOStmt->bindParam(':nom',$nom, PDO::PARAM_STR);
        $oPDOStmt->bindParam(':anneeDeNaissance',$anneeNaiss, PDO::PARAM_INT);
        $oPDOStmt->bindParam(':race',$race, PDO::PARAM_STR);

        //execution de la requette sql 
        $oPDOStmt->execute();

        $chien = $oPDOStmt->fetch(PDO::FETCH_ASSOC);
        return $chien;   
    }

    public function deleteChien($id){
        global $oPDO;
        //prepation de la requete sql 

        $oPDOStmt = $oPDO->prepare('DELETE FROM chien WHERE id = :id');
        $oPDOStmt->bindParam(':id',$id, PDO::PARAM_INT);
        //execution de la requette sql 
        $resultat = $oPDOStmt->execute();

        return $resultat; 
    }

    public function updateChien($id,$data){
        global $oPDO;
        //prepation de la requete sql 
    
        $oPDOStmt = $oPDO->prepare('UPDATE  chien SET sexe = :sexe,nom = :nom,anneeDeNaissance = :anneeDeNaissance,race = :race WHERE id = :id)');
        $oPDOStmt->bindParam(':id',$id, PDO::PARAM_INT);
        $oPDOStmt->bindParam(':sexe',$data['sexe'], PDO::PARAM_STR);
        $oPDOStmt->bindParam(':nom',$data['nom'], PDO::PARAM_STR);
        $oPDOStmt->bindParam(':anneeDeNaissance',$data['dateDeNaissance'], PDO::PARAM_INT);
        $oPDOStmt->bindParam(':race',$data['race'], PDO::PARAM_STR);
    
        //execution de la requette sql 
        $oPDOStmt->execute();
    
        $chien = $oPDOStmt->fetch(PDO::FETCH_ASSOC);
        return $chien;   
    }

    public function getChiensByRace($race){
        global $oPDO;
        //prepation de la requete sql 

        $oPDOStmt = $oPDO->prepare('SELECT id,sexe,nom,anneeDeNaissance FROM chien WHERE race = :race');
        $oPDOStmt->bindParam(':race',$race, PDO::PARAM_STR);

        //execution de la requette sql 
        $oPDOStmt->execute();

        $chiens = $oPDOStmt->fetchAll(PDO::FETCH_ASSOC);
        return $chiens;
    }


}


?>