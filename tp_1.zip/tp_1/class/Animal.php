<?php

class Animal {
    public  $id;
    public  $nom;
    public  $anneeNaissance;

    public function getAnimal(){
        return $this->id."/".$this->nom."/".$this->anneeNaissance ;
    }
    public function updateAnimal($id,$nom,$anneeNaissance){
        $this->id = $id;
        $this->nom = $nom;
        $this->anneeNaissance = $anneeNaissance;
        return;
    }

    public function deleteAnimal() {
        $this->id = 0;
        $this->nom = "";
        $this->anneeNaissance = 0;
        return;
    }

    public function createAnimal($id,$nom,$anneeNaissance){
        $this->id = $id;
        $this->nom = $nom;
        $this->anneeNaissance = $anneeNaissance;
        return;
    }





    
}

?>