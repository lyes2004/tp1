<?php 
//connextion a la base de donnees tp_1 avce pdo

$host = "localhost";
$db = "tp_1";
$user = "root";
$password = "";

$dns = "mysql:host=$host; dbname=$db; charset=UTF8";

try{
    $oPDO = new PDO($dns, $user , $password);

    if($oPDO){
        echo"Connected to $db datbase succesfully";
    }
}catch(PDOExeption $e){
    echo $e->getMessage();
}

require_once "class/Chien.php";

//utilisation de la methode getChien($id) qui retourne un chien avec l'id donner en parametre 

//creation d'un objet de type chien
$chien = new Chien;
echo "<br>";
echo "<br>";

//utilisation de la methode getChien($id) et affichage du resultat de notre methode \
echo "Methode getChien($ id)";
var_dump($chien->getChien(2));
echo "<br>";
echo "<br>";



//utilisation de la methode getAllChiens() qui retourne toute la liste des chiens  

//creation d'un objet de type chien
$chien2= new Chien;
echo "<br>";
echo "<br>";

//utilisation de la methode getAllChiens() et affichage du resultat de notre methode \
echo "Methode getAllChiens()";
var_dump($chien->getAllChiens());
echo "<br>";
echo "<br>";


//utilisation de la methode createChien($id,$nom,$race,$anneeNaiss,$sexe) qui cree un chien  

//creation d'un objet de type chien
$chien2= new Chien;
echo "<br>";
echo "<br>";

//utilisation de la methode createChien() et affichage du resultat de notre methode 
echo "Methode createChien()";
$id=1;
$nom="fox";
$race="chien loup";
$anneeNaiss=2021;
$sexe="male";
//verification de la creation de notre chien
var_dump($chien->getChien($id));
echo "<br>";
echo "<br>";


//utilisation de la methode deleteChien($id) qui supprime un chien de la base de donnees 

//creation d'un objet de type chien
$chien = new Chien;
echo "<br>";
echo "<br>";

//utilisation de la methode deleteChien($id) et affichage du resultat de notre methode 
echo "Methode deleteChien($ id)";
var_dump($chien->deleteChien(2));
echo "<br>";
echo "<br>";

//utilisation de la methode getChiensByRace($race) qui retourne une liste de chiens avec la meme race 

//creation d'un objet de type chien
$chien = new Chien;
echo "<br>";
echo "<br>";

//utilisation de la methode getChiensByRace($race) et affichage du resultat de notre methode 
echo "Methode getChiensByRace($ race)";
var_dump($chien->getChiensByRace("berger allmand"));
echo "<br>";
echo "<br>";

//utilisation de la methode updateChien($id,$data) qui mais a jours un chien dans la base de donnees par apport a son id 

//creation d'un objet de type chien
$ochien = new Livre;
$id = 1;
$chien = $ochien->getChien($id);
echo "<br>";

//Attribution des nouvel donnees 
$chien['race'] = "berger allmand";
$chien['anneeDeNaissance'] =2022;
$chien['nom']="toutou";

//utilisation de la methode getChiensByRace($race) et affichage du resultat de notre methode 
$result = $ochien->updateChien($id,$chien);
var_dump($result);
var_dump($ochien->getChien($id));
?>